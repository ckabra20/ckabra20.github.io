README for LIS-351 git repo for Chaitanya Kabra
